## DEMO

- Mybatis3
- Spring4
- Logback
- MySQL
- Ehcache
- Druid